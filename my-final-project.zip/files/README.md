# Put miscellaneous files in this folder
In particular:
* Your presentation slides as a PDF.
* Your demo video as an MP4. It must be >= 1920x1080 --- 1080p encoded with the H.264/MPEG-4 AVC codec.
