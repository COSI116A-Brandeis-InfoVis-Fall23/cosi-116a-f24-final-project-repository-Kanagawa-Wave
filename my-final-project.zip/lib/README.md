# Put JavaScript libraries you use in this folder

We already include D3 for you. For each library create a folder including a `LICENSE` text file with the software license for the library.